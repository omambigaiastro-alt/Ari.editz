export type Category =
  | 'Video Editing'
  | 'Motion Graphics'
  | 'Graphic Design'
  | 'Social Media'

export type Project = {
  id: string
  title: string
  category: Category
  description: string
  tools: string[]
  image: string
  // Optional external video/preview URL — opens in the lightbox when present
  video?: string
}

// Easy-to-edit portfolio projects. Replace images in /public/images
// and swap the `video` field with your own links.
export const projects: Project[] = [
  {
    id: 'wander',
    title: 'Wander — Travel Film',
    category: 'Video Editing',
    description:
      'A cinematic travel short cut to a driving score, balancing pace, rhythm and a warm golden-hour grade.',
    tools: ['Premiere Pro', 'DaVinci Resolve'],
    image: '/images/work-1.png',
  },
  {
    id: 'kinetic',
    title: 'Kinetic Type Reel',
    category: 'Motion Graphics',
    description:
      'Bold animated typography and glowing geometric transitions built for a brand launch sizzle.',
    tools: ['After Effects', 'Illustrator'],
    image: '/images/work-2.png',
  },
  {
    id: 'pulse',
    title: 'Pulse — Event Poster',
    category: 'Graphic Design',
    description:
      'A minimal, high-impact key art system with dramatic type for a live music event series.',
    tools: ['Photoshop', 'Illustrator'],
    image: '/images/work-3.png',
  },
  {
    id: 'drift',
    title: 'Drift — Fashion Reel',
    category: 'Social Media',
    description:
      'A punchy vertical reel with rhythmic cuts and motion blur, tuned for retention on Reels & Shorts.',
    tools: ['CapCut', 'Premiere Pro'],
    image: '/images/work-4.png',
  },
  {
    id: 'lumen',
    title: 'Lumen — Product Spot',
    category: 'Video Editing',
    description:
      'A moody commercial spot with macro detail, reflective surfaces and a refined teal-orange grade.',
    tools: ['Premiere Pro', 'After Effects'],
    image: '/images/work-5.png',
  },
  {
    id: 'apex',
    title: 'Apex — Thumbnail Set',
    category: 'Graphic Design',
    description:
      'A high-contrast thumbnail system designed to boost click-through with bold framing and glow.',
    tools: ['Photoshop'],
    image: '/images/work-6.png',
  },
]

export const filters = [
  'All',
  'Video Editing',
  'Motion Graphics',
  'Graphic Design',
  'Social Media',
] as const

export const stats = [
  { label: 'Projects Completed', value: '120+' },
  { label: 'Videos Edited', value: '340+' },
  { label: 'Designs Created', value: '500+' },
  { label: 'Years of Experience', value: '1+' },
]

export const services = [
  {
    title: 'Video Editing',
    items: [
      'YouTube videos',
      'Short-form content',
      'Reels & Shorts',
      'Promotional videos',
      'Cinematic edits',
    ],
  },
  {
    title: 'Motion Graphics',
    items: ['Titles', 'Logo animations', 'Transitions', 'Animated graphics'],
  },
  {
    title: 'Graphic Design',
    items: [
      'Posters',
      'Thumbnails',
      'Social media creatives',
      'Promotional designs',
    ],
  },
  {
    title: 'Color Grading',
    items: ['Cinematic looks', 'Mood creation', 'Color correction'],
  },
  {
    title: 'Social Media Content',
    items: [
      'Instagram Reels',
      'YouTube Shorts',
      'Social media advertisements',
    ],
  },
]

export const skills = [
  { name: 'Adobe Premiere Pro', level: 'Expert' },
  { name: 'After Effects', level: 'Advanced' },
  { name: 'Photoshop', level: 'Expert' },
  { name: 'Illustrator', level: 'Advanced' },
  { name: 'DaVinci Resolve', level: 'Advanced' },
  { name: 'CapCut', level: 'Expert' },
  { name: 'Blender', level: 'Intermediate' },
]

export const process = [
  {
    step: '01',
    title: 'Brief',
    description: 'Understand the idea, audience and requirements.',
  },
  {
    step: '02',
    title: 'Create',
    description: 'Plan the edit, visuals, graphics and overall style.',
  },
  {
    step: '03',
    title: 'Refine',
    description:
      'Editing, motion graphics, sound, color and detailed polishing.',
  },
  {
    step: '04',
    title: 'Deliver',
    description: 'Final quality check and delivery in the required format.',
  },
]

export const testimonials = [
  {
    quote:
      'Placeholder testimonial — replace with a real client quote about the collaboration, turnaround and final result.',
    name: 'Client Name',
    role: 'Role / Company',
  },
  {
    quote:
      'Placeholder testimonial — describe how the edit or design elevated the brand and drove engagement.',
    name: 'Client Name',
    role: 'Role / Company',
  },
  {
    quote:
      'Placeholder testimonial — highlight communication, creativity and reliability throughout the project.',
    name: 'Client Name',
    role: 'Role / Company',
  },
]

export const navLinks = [
  { label: 'Home', href: '#home' },
  { label: 'About', href: '#about' },
  { label: 'Services', href: '#services' },
  { label: 'Portfolio', href: '#portfolio' },
  { label: 'Workflow', href: '#workflow' },
  { label: 'Contact', href: '#contact' },
]
