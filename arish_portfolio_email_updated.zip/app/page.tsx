import { Navbar } from '@/components/navbar'
import { Hero } from '@/components/hero'
import { About } from '@/components/about'
import { Services } from '@/components/services'
import { Portfolio } from '@/components/portfolio'
import { Featured } from '@/components/featured'
import { Skills } from '@/components/skills'
import { Workflow } from '@/components/workflow'
import { Testimonials } from '@/components/testimonials'
import { Contact } from '@/components/contact'
import { Footer } from '@/components/footer'

export default function Page() {
  return (
    <>
      <Navbar />
      <main>
        <Hero />
        <About />
        <Services />
        <Portfolio />
        <Featured />
        <Skills />
        <Workflow />
        <Testimonials />
        <Contact />
      </main>
      <Footer />
    </>
  )
}
