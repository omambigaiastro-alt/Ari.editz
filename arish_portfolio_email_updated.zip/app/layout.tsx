import { Analytics } from '@vercel/analytics/next'
import type { Metadata, Viewport } from 'next'
import { Inter, Space_Grotesk } from 'next/font/google'
import './globals.css'

const inter = Inter({
  subsets: ['latin'],
  variable: '--font-inter',
  display: 'swap',
})

const spaceGrotesk = Space_Grotesk({
  subsets: ['latin'],
  variable: '--font-space',
  display: 'swap',
})

export const metadata: Metadata = {
  title: 'Arish Gokul — Video Editor & Graphics Designer',
  description:
    'Cinematic video editing, motion graphics, and bold visual design by Arish Gokul. Crafting edits, visuals, and creative digital experiences that tell stories.',
  generator: 'v0.app',
  keywords: [
    'video editor',
    'graphics designer',
    'motion graphics',
    'color grading',
    'Arish Gokul',
    'portfolio',
  ],
  openGraph: {
    title: 'Arish Gokul — Video Editor & Graphics Designer',
    description:
      'Cinematic edits, engaging visuals, and creative digital experiences.',
    type: 'website',
  },
}

export const viewport: Viewport = {
  colorScheme: 'dark',
  themeColor: '#1a1712',
}

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode
}>) {
  return (
    <html lang="en" className={`${inter.variable} ${spaceGrotesk.variable} bg-background`}>
      <body className="grain font-sans antialiased">
        {children}
        {process.env.NODE_ENV === 'production' && <Analytics />}
      </body>
    </html>
  )
}
