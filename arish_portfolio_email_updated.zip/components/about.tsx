import Image from 'next/image'
import { Reveal } from '@/components/reveal'
import { stats } from '@/lib/data'

const focus = [
  'Creative storytelling',
  'Video editing',
  'Motion graphics',
  'Graphic design',
  'Color grading',
  'Social media content',
  'Visual effects',
]

export function About() {
  return (
    <section id="about" className="relative py-24 md:py-32">
      <div className="mx-auto max-w-7xl px-5 md:px-8">
        <div className="grid items-center gap-12 lg:grid-cols-2 lg:gap-16">
          <Reveal className="relative">
            <div className="relative aspect-4/5 overflow-hidden rounded-2xl border border-border/60">
              <Image
                src="/images/profile.png"
                alt="Portrait of Arish Gokul in the studio"
                fill
                sizes="(max-width: 1024px) 100vw, 45vw"
                className="object-cover"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-background/60 to-transparent" />
            </div>
            <div className="absolute -bottom-5 -right-4 rounded-2xl border border-border/60 bg-card/90 px-6 py-4 backdrop-blur sm:-right-6">
              <p className="font-display text-3xl font-bold text-primary">5+</p>
              <p className="text-xs tracking-wide text-muted-foreground uppercase">
                Years crafting visuals
              </p>
            </div>
          </Reveal>

          <div>
            <Reveal>
              <p className="mb-3 text-sm font-medium tracking-[0.3em] text-primary uppercase">
                About Me
              </p>
              <h2 className="font-display text-3xl font-bold text-balance sm:text-4xl md:text-5xl">
                Turning raw footage and ideas into stories worth watching.
              </h2>
            </Reveal>

            <Reveal delay={100}>
              <p className="mt-6 text-lg leading-relaxed text-muted-foreground text-pretty">
                I&apos;m Arish Gokul, a creative video editor and graphics
                designer. I transform raw footage and rough ideas into engaging
                visual content — pairing sharp editing instincts with a strong
                design eye to help brands and creators stand out.
              </p>
            </Reveal>

            <Reveal delay={150}>
              <ul className="mt-8 flex flex-wrap gap-2.5">
                {focus.map((item) => (
                  <li
                    key={item}
                    className="rounded-full border border-border/60 bg-secondary/40 px-4 py-1.5 text-sm text-muted-foreground"
                  >
                    {item}
                  </li>
                ))}
              </ul>
            </Reveal>
          </div>
        </div>

        {/* Stats */}
        <div className="mt-20 grid grid-cols-2 gap-px overflow-hidden rounded-2xl border border-border/60 bg-border/60 lg:grid-cols-4">
          {stats.map((stat, i) => (
            <Reveal
              key={stat.label}
              delay={i * 80}
              className="bg-card px-6 py-8 text-center"
            >
              <p className="font-display text-4xl font-bold text-foreground md:text-5xl">
                {stat.value}
              </p>
              <p className="mt-2 text-sm text-muted-foreground">{stat.label}</p>
            </Reveal>
          ))}
        </div>
      </div>
    </section>
  )
}
