'use client'

import { useEffect, useState } from 'react'
import Image from 'next/image'
import { Play, X, ArrowUpRight } from 'lucide-react'
import { filters, projects, type Project } from '@/lib/data'
import { cn } from '@/lib/utils'

export function Portfolio() {
  const [active, setActive] = useState<(typeof filters)[number]>('All')
  const [selected, setSelected] = useState<Project | null>(null)

  const visible =
    active === 'All'
      ? projects
      : projects.filter((p) => p.category === active)

  useEffect(() => {
    document.body.style.overflow = selected ? 'hidden' : ''
    const onKey = (e: KeyboardEvent) => {
      if (e.key === 'Escape') setSelected(null)
    }
    window.addEventListener('keydown', onKey)
    return () => {
      document.body.style.overflow = ''
      window.removeEventListener('keydown', onKey)
    }
  }, [selected])

  return (
    <section id="portfolio" className="relative py-24 md:py-32">
      <div className="mx-auto max-w-7xl px-5 md:px-8">
        <div className="flex flex-col gap-8 md:flex-row md:items-end md:justify-between">
          <div className="max-w-2xl">
            <p className="mb-3 text-sm font-medium tracking-[0.3em] text-primary uppercase">
              Selected Work
            </p>
            <h2 className="font-display text-3xl font-bold text-balance sm:text-4xl md:text-5xl">
              A reel of edits, visuals and designs.
            </h2>
          </div>

          {/* Filters */}
          <div className="flex flex-wrap gap-2">
            {filters.map((filter) => (
              <button
                key={filter}
                type="button"
                onClick={() => setActive(filter)}
                className={cn(
                  'rounded-full border px-4 py-2 text-sm font-medium transition-colors',
                  active === filter
                    ? 'border-primary bg-primary text-primary-foreground'
                    : 'border-border/60 bg-secondary/40 text-muted-foreground hover:text-foreground',
                )}
              >
                {filter}
              </button>
            ))}
          </div>
        </div>

        <div className="mt-12 grid gap-5 sm:grid-cols-2 lg:grid-cols-3">
          {visible.map((project) => (
            <button
              key={project.id}
              type="button"
              onClick={() => setSelected(project)}
              className="group relative aspect-video overflow-hidden rounded-2xl border border-border/60 text-left"
            >
              <Image
                src={project.image || '/placeholder.svg'}
                alt={project.title}
                fill
                sizes="(max-width: 640px) 100vw, (max-width: 1024px) 50vw, 33vw"
                className="object-cover transition-transform duration-500 group-hover:scale-105"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-background via-background/30 to-transparent opacity-90" />

              {/* Play badge */}
              <span className="absolute right-4 top-4 inline-flex size-11 items-center justify-center rounded-full bg-background/60 text-foreground opacity-0 backdrop-blur transition-all duration-300 group-hover:scale-100 group-hover:opacity-100 scale-90">
                <Play className="size-4 fill-current" />
              </span>

              <div className="absolute inset-x-0 bottom-0 p-5">
                <span className="text-xs font-medium tracking-wide text-primary uppercase">
                  {project.category}
                </span>
                <h3 className="mt-1 font-display text-lg font-semibold text-foreground">
                  {project.title}
                </h3>
              </div>
            </button>
          ))}
        </div>
      </div>

      {/* Lightbox */}
      {selected && (
        <div
          className="fixed inset-0 z-[70] flex items-center justify-center bg-background/90 p-4 backdrop-blur-md"
          onClick={() => setSelected(null)}
          role="dialog"
          aria-modal="true"
          aria-label={selected.title}
        >
          <div
            className="relative w-full max-w-4xl overflow-hidden rounded-2xl border border-border/60 bg-card"
            onClick={(e) => e.stopPropagation()}
          >
            <button
              type="button"
              onClick={() => setSelected(null)}
              className="absolute right-4 top-4 z-10 inline-flex size-10 items-center justify-center rounded-full bg-background/70 text-foreground backdrop-blur transition-colors hover:text-primary"
              aria-label="Close"
            >
              <X className="size-5" />
            </button>

            <div className="relative aspect-video">
              <Image
                src={selected.image || '/placeholder.svg'}
                alt={selected.title}
                fill
                sizes="100vw"
                className="object-cover"
              />
              <div className="absolute inset-0 flex items-center justify-center bg-background/30">
                <span className="inline-flex size-16 items-center justify-center rounded-full bg-primary text-primary-foreground">
                  <Play className="size-6 fill-current" />
                </span>
              </div>
            </div>

            <div className="p-6 md:p-8">
              <span className="text-xs font-medium tracking-widest text-primary uppercase">
                {selected.category}
              </span>
              <h3 className="mt-2 font-display text-2xl font-bold">
                {selected.title}
              </h3>
              <p className="mt-3 leading-relaxed text-muted-foreground text-pretty">
                {selected.description}
              </p>
              <div className="mt-5 flex flex-wrap items-center justify-between gap-4">
                <ul className="flex flex-wrap gap-2">
                  {selected.tools.map((tool) => (
                    <li
                      key={tool}
                      className="rounded-full border border-border/60 bg-secondary/40 px-3 py-1 text-xs text-muted-foreground"
                    >
                      {tool}
                    </li>
                  ))}
                </ul>
                <a
                  href="#contact"
                  onClick={() => setSelected(null)}
                  className="inline-flex items-center gap-1.5 text-sm font-semibold text-primary hover:underline"
                >
                  Start a project like this
                  <ArrowUpRight className="size-4" />
                </a>
              </div>
            </div>
          </div>
        </div>
      )}
    </section>
  )
}
