import {
  Clapperboard,
  Sparkles,
  PenTool,
  Palette,
  Smartphone,
  Check,
  type LucideIcon,
} from 'lucide-react'
import { Reveal } from '@/components/reveal'
import { services } from '@/lib/data'

const icons: Record<string, LucideIcon> = {
  'Video Editing': Clapperboard,
  'Motion Graphics': Sparkles,
  'Graphic Design': PenTool,
  'Color Grading': Palette,
  'Social Media Content': Smartphone,
}

export function Services() {
  return (
    <section id="services" className="relative py-24 md:py-32">
      <div className="mx-auto max-w-7xl px-5 md:px-8">
        <Reveal className="max-w-2xl">
          <p className="mb-3 text-sm font-medium tracking-[0.3em] text-primary uppercase">
            What I Do
          </p>
          <h2 className="font-display text-3xl font-bold text-balance sm:text-4xl md:text-5xl">
            Services built around your story.
          </h2>
        </Reveal>

        <div className="mt-14 grid gap-5 sm:grid-cols-2 lg:grid-cols-3">
          {services.map((service, i) => {
            const Icon = icons[service.title] ?? Sparkles
            return (
              <Reveal
                key={service.title}
                delay={(i % 3) * 90}
                as="article"
                className="group relative flex flex-col overflow-hidden rounded-2xl border border-border/60 bg-card p-7 transition-colors hover:border-primary/50"
              >
                <div className="pointer-events-none absolute -right-16 -top-16 size-40 rounded-full bg-primary/10 opacity-0 blur-3xl transition-opacity duration-500 group-hover:opacity-100" />
                <div className="mb-6 inline-flex size-12 items-center justify-center rounded-xl bg-primary/10 text-primary transition-colors group-hover:bg-primary group-hover:text-primary-foreground">
                  <Icon className="size-6" />
                </div>
                <h3 className="font-display text-xl font-semibold">
                  {service.title}
                </h3>
                <ul className="mt-4 flex flex-col gap-2.5">
                  {service.items.map((item) => (
                    <li
                      key={item}
                      className="flex items-center gap-2.5 text-sm text-muted-foreground"
                    >
                      <Check className="size-4 shrink-0 text-primary" />
                      {item}
                    </li>
                  ))}
                </ul>
              </Reveal>
            )
          })}
        </div>
      </div>
    </section>
  )
}
