'use client'

import { useState, type FormEvent } from 'react'
import { Mail, Youtube, Linkedin, ArrowUpRight, Send } from '@/components/icons'

const socials = [
  { label: 'Instagram', handle: '@4ri.editzz', href: 'https://www.instagram.com/4ri.editzz', icon: null },
  { label: 'YouTube', href: '#', icon: Youtube },
  { label: 'LinkedIn', href: '#', icon: Linkedin },
]

const CONTACT_EMAIL = 'om.ambigai.astro@gmail.com'

export function Contact() {
  const [sent, setSent] = useState(false)

  function handleSubmit(e: FormEvent<HTMLFormElement>) {
    e.preventDefault()
    const form = e.currentTarget
    const data = new FormData(form)
    const name = String(data.get('name') ?? '')
    const email = String(data.get('email') ?? '')
    const projectType = String(data.get('projectType') ?? '')
    const message = String(data.get('message') ?? '')

    const subject = `New project inquiry from ${name}`
    const body = `Name: ${name}\nEmail: ${email}\nProject type: ${projectType}\n\n${message}`
    window.location.href = `mailto:${CONTACT_EMAIL}?subject=${encodeURIComponent(
      subject,
    )}&body=${encodeURIComponent(body)}`
    setSent(true)
  }

  return (
    <section id="contact" className="relative py-24 md:py-32">
      <div className="mx-auto max-w-7xl px-5 md:px-8">
        <div className="overflow-hidden rounded-3xl border border-border/60 bg-card">
          <div className="grid lg:grid-cols-2">
            {/* Left — pitch */}
            <div className="relative flex flex-col justify-between gap-10 p-8 md:p-12">
              <div className="pointer-events-none absolute -left-20 -top-20 size-64 rounded-full bg-primary/10 blur-3xl" />
              <div className="relative">
                <p className="mb-3 text-sm font-medium tracking-[0.3em] text-primary uppercase">
                  Let&apos;s Talk
                </p>
                <h2 className="font-display text-3xl font-bold text-balance sm:text-4xl md:text-5xl">
                  Got a project in mind? Let&apos;s create something great.
                </h2>
                <p className="mt-5 max-w-md leading-relaxed text-muted-foreground text-pretty">
                  Whether it&apos;s a cinematic edit, a motion graphics reel or a
                  full design system — tell me about your idea and let&apos;s
                  bring it to life.
                </p>
              </div>

              <div className="relative flex flex-col gap-5">
                <a
                  href={`mailto:${CONTACT_EMAIL}`}
                  className="inline-flex items-center gap-3 text-foreground transition-colors hover:text-primary"
                >
                  <span className="inline-flex size-11 items-center justify-center rounded-xl bg-primary/10 text-primary">
                    <Mail className="size-5" />
                  </span>
                  {CONTACT_EMAIL}
                </a>

                <div className="flex gap-3">
                  {socials.map((social) => (
                    <a
                      key={social.label}
                      href={social.href}
                      aria-label={social.label}
                      className="inline-flex size-11 items-center justify-center rounded-xl border border-border/60 text-muted-foreground transition-colors hover:border-primary/60 hover:text-primary"
                    >
                      {social.icon ? (
                        <social.icon className="size-5" />
                      ) : (
                        <span className="text-xs font-semibold tracking-tight">
                          {social.handle}
                        </span>
                      )}
                    </a>
                  ))}
                </div>
              </div>
            </div>

            {/* Right — form */}
            <div className="border-t border-border/60 bg-secondary/20 p-8 md:border-l md:border-t-0 md:p-12">
              {sent ? (
                <div className="flex h-full min-h-64 flex-col items-center justify-center text-center">
                  <span className="inline-flex size-14 items-center justify-center rounded-full bg-primary/15 text-primary">
                    <Send className="size-6" />
                  </span>
                  <h3 className="mt-5 font-display text-2xl font-semibold">
                    Almost there!
                  </h3>
                  <p className="mt-2 max-w-xs text-muted-foreground text-pretty">
                    Your email draft is ready in your mail app. Hit send and
                    I&apos;ll get back to you shortly.
                  </p>
                  <button
                    type="button"
                    onClick={() => setSent(false)}
                    className="mt-6 text-sm font-semibold text-primary hover:underline"
                  >
                    Send another message
                  </button>
                </div>
              ) : (
                <form onSubmit={handleSubmit} className="flex flex-col gap-5">
                  <Field label="Name" htmlFor="name">
                    <input
                      id="name"
                      name="name"
                      required
                      placeholder="Your name"
                      className={inputClass}
                    />
                  </Field>
                  <Field label="Email" htmlFor="email">
                    <input
                      id="email"
                      name="email"
                      type="email"
                      required
                      placeholder="you@email.com"
                      className={inputClass}
                    />
                  </Field>
                  <Field label="Project type" htmlFor="projectType">
                    <select
                      id="projectType"
                      name="projectType"
                      defaultValue="Video Editing"
                      className={inputClass}
                    >
                      <option>Video Editing</option>
                      <option>Motion Graphics</option>
                      <option>Graphic Design</option>
                      <option>Color Grading</option>
                      <option>Social Media Content</option>
                      <option>Other</option>
                    </select>
                  </Field>
                  <Field label="Message" htmlFor="message">
                    <textarea
                      id="message"
                      name="message"
                      required
                      rows={4}
                      placeholder="Tell me about your project..."
                      className={`${inputClass} resize-none`}
                    />
                  </Field>

                  <button
                    type="submit"
                    className="group mt-2 inline-flex items-center justify-center gap-2 rounded-full bg-primary px-6 py-3.5 text-base font-semibold text-primary-foreground transition-transform hover:scale-[1.02]"
                  >
                    Send Message
                    <ArrowUpRight className="size-5 transition-transform group-hover:translate-x-0.5 group-hover:-translate-y-0.5" />
                  </button>
                </form>
              )}
            </div>
          </div>
        </div>
      </div>
    </section>
  )
}

const inputClass =
  'w-full rounded-xl border border-border/60 bg-background/60 px-4 py-3 text-sm text-foreground outline-none transition-colors placeholder:text-muted-foreground/70 focus:border-primary/60 focus:ring-2 focus:ring-primary/20'

function Field({
  label,
  htmlFor,
  children,
}: {
  label: string
  htmlFor: string
  children: React.ReactNode
}) {
  return (
    <div className="flex flex-col gap-2">
      <label
        htmlFor={htmlFor}
        className="text-sm font-medium text-foreground"
      >
        {label}
      </label>
      {children}
    </div>
  )
}
