'use client'

import { useState } from 'react'
import { Quote, ChevronLeft, ChevronRight } from 'lucide-react'
import { testimonials } from '@/lib/data'
import { cn } from '@/lib/utils'

export function Testimonials() {
  const [index, setIndex] = useState(0)
  const count = testimonials.length

  const go = (dir: number) => setIndex((i) => (i + dir + count) % count)

  return (
    <section className="relative py-24 md:py-32">
      <div className="mx-auto max-w-4xl px-5 text-center md:px-8">
        <p className="mb-3 text-sm font-medium tracking-[0.3em] text-primary uppercase">
          Kind Words
        </p>
        <h2 className="font-display text-3xl font-bold text-balance sm:text-4xl md:text-5xl">
          Trusted by creators &amp; brands.
        </h2>

        <div className="relative mt-14">
          <Quote className="mx-auto size-10 text-primary/40" />
          <blockquote className="mx-auto mt-6 min-h-[7rem] max-w-2xl text-xl leading-relaxed text-foreground text-pretty md:text-2xl">
            {testimonials[index].quote}
          </blockquote>
          <div className="mt-8">
            <p className="font-display text-lg font-semibold">
              {testimonials[index].name}
            </p>
            <p className="text-sm text-muted-foreground">
              {testimonials[index].role}
            </p>
          </div>

          <div className="mt-10 flex items-center justify-center gap-4">
            <button
              type="button"
              onClick={() => go(-1)}
              className="inline-flex size-11 items-center justify-center rounded-full border border-border/60 text-foreground transition-colors hover:border-primary/60 hover:text-primary"
              aria-label="Previous testimonial"
            >
              <ChevronLeft className="size-5" />
            </button>

            <div className="flex items-center gap-2">
              {testimonials.map((_, i) => (
                <button
                  key={i}
                  type="button"
                  onClick={() => setIndex(i)}
                  aria-label={`Go to testimonial ${i + 1}`}
                  className={cn(
                    'h-2 rounded-full transition-all',
                    i === index
                      ? 'w-6 bg-primary'
                      : 'w-2 bg-border hover:bg-muted-foreground',
                  )}
                />
              ))}
            </div>

            <button
              type="button"
              onClick={() => go(1)}
              className="inline-flex size-11 items-center justify-center rounded-full border border-border/60 text-foreground transition-colors hover:border-primary/60 hover:text-primary"
              aria-label="Next testimonial"
            >
              <ChevronRight className="size-5" />
            </button>
          </div>
        </div>
      </div>
    </section>
  )
}
