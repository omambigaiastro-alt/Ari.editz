import Image from 'next/image'
import { ArrowUpRight, Play } from 'lucide-react'

export function Hero() {
  return (
    <section
      id="home"
      className="relative flex min-h-screen items-center overflow-hidden pt-16"
    >
      {/* Background image + cinematic overlays */}
      <div className="absolute inset-0 -z-10">
        <Image
          src="/images/hero-workstation.png"
          alt="Cinematic video editing workstation with a color-graded timeline"
          fill
          priority
          sizes="100vw"
          className="object-cover object-center opacity-40"
        />
        <div className="absolute inset-0 bg-gradient-to-t from-background via-background/85 to-background/40" />
        <div className="absolute inset-0 bg-gradient-to-r from-background via-background/40 to-transparent" />
        <div className="absolute -left-40 top-1/3 size-[32rem] rounded-full bg-primary/15 blur-[120px]" />
      </div>

      <div className="mx-auto w-full max-w-7xl px-5 md:px-8">
        <div className="max-w-3xl">
          <p className="mb-6 inline-flex items-center gap-2 rounded-full border border-border/60 bg-secondary/40 px-4 py-1.5 text-xs font-medium tracking-widest text-muted-foreground uppercase backdrop-blur">
            <span className="size-1.5 rounded-full bg-primary" />
            Video Editor &amp; Graphics Designer
          </p>

          <h1 className="font-display text-5xl leading-[0.95] font-bold text-balance sm:text-6xl md:text-7xl lg:text-8xl">
            I EDIT STORIES.
            <br />
            I DESIGN{' '}
            <span className="text-primary">IMPACT.</span>
          </h1>

          <p className="mt-8 max-w-xl text-lg leading-relaxed text-muted-foreground text-pretty">
            Crafting cinematic edits, engaging visuals, and creative digital
            experiences that people remember.
          </p>

          <div className="mt-10 flex flex-col gap-4 sm:flex-row">
            <a
              href="#portfolio"
              className="group inline-flex items-center justify-center gap-2 rounded-full bg-primary px-7 py-3.5 text-base font-semibold text-primary-foreground transition-transform hover:scale-[1.03]"
            >
              View My Work
              <ArrowUpRight className="size-5 transition-transform group-hover:translate-x-0.5 group-hover:-translate-y-0.5" />
            </a>
            <a
              href="#contact"
              className="group inline-flex items-center justify-center gap-2 rounded-full border border-border bg-background/40 px-7 py-3.5 text-base font-semibold text-foreground backdrop-blur transition-colors hover:border-primary/60 hover:text-primary"
            >
              <Play className="size-4 fill-current" />
              Let&apos;s Work Together
            </a>
          </div>
        </div>
      </div>

      {/* Scroll indicator */}
      <div className="pointer-events-none absolute bottom-8 left-1/2 -translate-x-1/2">
        <div className="flex h-11 w-6 items-start justify-center rounded-full border border-border/70 p-1.5">
          <div className="size-1.5 animate-bounce rounded-full bg-primary" />
        </div>
      </div>
    </section>
  )
}
