import { Reveal } from '@/components/reveal'
import { skills } from '@/lib/data'

// Duplicated for a seamless marquee loop
const marquee = [...skills, ...skills]

export function Skills() {
  return (
    <section className="relative overflow-hidden py-24 md:py-32">
      <div className="mx-auto max-w-7xl px-5 md:px-8">
        <Reveal className="max-w-2xl">
          <p className="mb-3 text-sm font-medium tracking-[0.3em] text-primary uppercase">
            Tools &amp; Skills
          </p>
          <h2 className="font-display text-3xl font-bold text-balance sm:text-4xl md:text-5xl">
            The software behind the craft.
          </h2>
        </Reveal>
      </div>

      {/* Marquee */}
      <div className="relative mt-14 flex overflow-hidden [mask-image:linear-gradient(to_right,transparent,black_10%,black_90%,transparent)]">
        <div className="flex shrink-0 animate-marquee gap-4 pr-4">
          {marquee.map((skill, i) => (
            <div
              key={`${skill.name}-${i}`}
              className="flex shrink-0 items-center gap-4 rounded-2xl border border-border/60 bg-card px-7 py-5"
            >
              <span className="font-display text-xl font-semibold whitespace-nowrap">
                {skill.name}
              </span>
              <span className="rounded-full bg-primary/10 px-3 py-1 text-xs font-medium text-primary">
                {skill.level}
              </span>
            </div>
          ))}
        </div>
      </div>
    </section>
  )
}
