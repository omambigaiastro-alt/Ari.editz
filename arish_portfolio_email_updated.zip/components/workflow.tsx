import { Reveal } from '@/components/reveal'
import { process } from '@/lib/data'

export function Workflow() {
  return (
    <section id="workflow" className="relative py-24 md:py-32">
      <div className="mx-auto max-w-7xl px-5 md:px-8">
        <Reveal className="max-w-2xl">
          <p className="mb-3 text-sm font-medium tracking-[0.3em] text-primary uppercase">
            How I Work
          </p>
          <h2 className="font-display text-3xl font-bold text-balance sm:text-4xl md:text-5xl">
            A simple process, a polished result.
          </h2>
        </Reveal>

        <ol className="mt-14 grid gap-5 sm:grid-cols-2 lg:grid-cols-4">
          {process.map((item, i) => (
            <Reveal
              key={item.step}
              as="li"
              delay={i * 90}
              className="relative flex flex-col rounded-2xl border border-border/60 bg-card p-7"
            >
              <span className="font-display text-5xl font-bold text-primary/25">
                {item.step}
              </span>
              <h3 className="mt-4 font-display text-xl font-semibold">
                {item.title}
              </h3>
              <p className="mt-2 text-sm leading-relaxed text-muted-foreground">
                {item.description}
              </p>
            </Reveal>
          ))}
        </ol>
      </div>
    </section>
  )
}
