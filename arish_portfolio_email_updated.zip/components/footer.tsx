import { navLinks } from '@/lib/data'

export function Footer() {
  const year = new Date().getFullYear()

  return (
    <footer className="border-t border-border/60 py-12">
      <div className="mx-auto max-w-7xl px-5 md:px-8">
        <div className="flex flex-col items-center justify-between gap-8 md:flex-row">
          <a
            href="#home"
            className="font-display text-lg font-bold tracking-[0.2em]"
          >
            ARISH<span className="text-primary">.</span>GOKUL
          </a>

          <ul className="flex flex-wrap items-center justify-center gap-x-6 gap-y-2">
            {navLinks.map((link) => (
              <li key={link.href}>
                <a
                  href={link.href}
                  className="text-sm text-muted-foreground transition-colors hover:text-foreground"
                >
                  {link.label}
                </a>
              </li>
            ))}
          </ul>
        </div>

        <div className="mt-10 flex flex-col items-center justify-between gap-3 border-t border-border/60 pt-6 text-sm text-muted-foreground md:flex-row">
          <p>© {year} Arish Gokul. All rights reserved.</p>
          <p>Video Editor &amp; Graphics Designer</p>
        </div>
      </div>
    </footer>
  )
}
