import Image from 'next/image'
import { Play } from 'lucide-react'
import { Reveal } from '@/components/reveal'

export function Featured() {
  return (
    <section className="relative py-12 md:py-20">
      <div className="mx-auto max-w-7xl px-5 md:px-8">
        <Reveal className="group relative overflow-hidden rounded-3xl border border-border/60">
          <div className="relative aspect-video md:aspect-21/9">
            <Image
              src="/images/featured.png"
              alt="Featured cinematic film still with dramatic color grade"
              fill
              sizes="(max-width: 1280px) 100vw, 1280px"
              className="object-cover transition-transform duration-700 group-hover:scale-105"
            />
            <div className="absolute inset-0 bg-gradient-to-t from-background via-background/50 to-background/10" />
            <div className="absolute inset-0 bg-gradient-to-r from-background/70 to-transparent" />
          </div>

          <div className="absolute inset-0 flex flex-col justify-end p-6 md:p-12">
            <div className="max-w-xl">
              <p className="mb-3 text-xs font-medium tracking-[0.3em] text-primary uppercase">
                Featured Project
              </p>
              <h2 className="font-display text-3xl font-bold text-balance md:text-5xl">
                A cinematic brand film, cut &amp; graded end to end.
              </h2>
              <p className="mt-4 max-w-md leading-relaxed text-muted-foreground text-pretty">
                Editing, motion graphics, sound design and color — a full
                creative pipeline delivered for a single, unforgettable story.
              </p>
              <a
                href="#portfolio"
                className="mt-7 inline-flex items-center gap-2.5 rounded-full bg-primary px-6 py-3 text-sm font-semibold text-primary-foreground transition-transform hover:scale-105"
              >
                <Play className="size-4 fill-current" />
                Watch the breakdown
              </a>
            </div>
          </div>
        </Reveal>
      </div>
    </section>
  )
}
